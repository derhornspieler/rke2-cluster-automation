# Harvester Network Monitoring (DeepFlow)

This Helm chart deploys a DeepFlow-based network observability stack onto a Harvester (Kubernetes) cluster:
- DeepFlow agents (DaemonSet) using eBPF on each node
- DeepFlow server (StatefulSet)
- MySQL and ClickHouse backends
- Grafana for dashboards

## Directory layout

harvester-network-monitoring/
├── Chart.yaml
├── values.yaml
└── templates/
    ├── namespace.yaml
    ├── deepflow-agent-daemonset.yaml
    ├── deepflow-server-statefulset.yaml
    ├── deepflow-clickhouse-statefulset.yaml
    ├── deepflow-mysql-statefulset.yaml
    ├── deepflow-grafana-deployment.yaml
    ├── service-deepflow.yaml
    ├── service-grafana.yaml
    ├── service-mysql.yaml
    ├── service-clickhouse.yaml
    ├── networkpolicy-server.yaml
    ├── networkpolicy-databases.yaml
    └── rbac.yaml

## Quick start

```bash
kubectl create namespace deepflow
helm install harvester-netmon ./harvester-network-monitoring -n deepflow
```

Then:

```bash
NODE=$(kubectl get nodes -o jsonpath="{.items[0].status.addresses[0].address}")
PORT=$(kubectl get svc harvester-netmon-grafana -n deepflow -o jsonpath="{.spec.ports[0].nodePort}")
echo "http://$NODE:$PORT"
```
